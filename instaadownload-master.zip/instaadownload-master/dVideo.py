
class dVideo(object):
    def __init__(self, header, upload_id, recipient):
        self.username = None
        self.download_from = None
        self.header = header
        self.upload_id = upload_id
        self.recipient = recipient